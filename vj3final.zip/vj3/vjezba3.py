#!C:\ProgramData\Anaconda3\python.exe
import cgi
import os
from http import cookies
import subjects

params = cgi.FieldStorage()
cookies_string = os.environ.get('HTTP_COOKIE', '')
cookie_object = cookies.SimpleCookie(cookies_string)
method = os.environ.get('REQUEST_METHOD', 'GET').upper()

def spremi_u_cookies(): #sprema odabir iz POST metode u cookies
    new_cookie = cookies.SimpleCookie()
    for subject_id in subjects.subjects:
        vrijednost = params.getvalue(subject_id)
        if vrijednost is not None: #ako je vrijednost odabrana, spremi ju u cookies
            new_cookie[subject_id] = vrijednost   #cookiji se nadopunjuju

    if new_cookie:
        print(new_cookie.output()) 


def dohvati_status(subject_id):
    #params se cita prvo, a ako u params nema nista, onda cita cookie
    if method == 'POST':
        param_val = params.getvalue(subject_id)
        if param_val is not None:
            return param_val #ako je vrijednost odabrana, vrati ju
#gledaj params
    if cookie_object.get(subject_id):
        return cookie_object[subject_id].value #ako je vrijednost spremljena u cookies, vrati ju
    return 'not' #ako nije odabrana ni spremljena, vrati not

def ispis_predmeta(subject_id, subject_data): #ispis jednog predmeta
    status = dohvati_status(subject_id) #trenutni status je li checked
    print(f'<tr><td>{subject_data["name"]}</td><td>{subject_data["ects"]}</td>')
    for status_id, status_name in subjects.status_names.items():
        checked = 'checked' if status == status_id else ''
        print(f'''<td>
            <input type="radio" name="{subject_id}"
                   value="{status_id}" {checked}> {status_name}
        </td>''')
    print('</tr>')

def ispis_predmeta_godine(year):
    print(f'<h2>{subjects.year_names[year]}</h2>')
    print('<table border="1"><tr><th>Predmet</th><th>ECTS</th>')
    for status_name in subjects.status_names.values():
        print(f'<th>{status_name}</th>')
    print('</tr>')
    for subject_id, subject_data in subjects.subjects.items():
        if subject_data['year'] == year:
            ispis_predmeta(subject_id, subject_data)
    print('</table>')

def ispis_upisnog_lista():
    ukupno_ects = 0
    print('<h2>Upisni list</h2>')
    print('<table border="1">')
    print('<tr><th>Godina</th><th>Predmet</th><th>ECTS</th><th>Status</th></tr>')
    for subject_id, subject_data in subjects.subjects.items():
        status = dohvati_status(subject_id)
        if status != 'not':
            year_name  = subjects.year_names[subject_data['year']]
            status_name = subjects.status_names[status]
            ects = subject_data['ects']
            if status == 'enr':
                ukupno_ects+=ects
            print(f'<tr><td>{year_name}</td><td>{subject_data["name"]}</td>'
                  f'<td>{subject_data["ects"]}</td><td>{status_name}</td></tr>')
    print('</table>')

    #fali zbroj bodova je li enr i zbrojiti upisane bodove
    print(f'<tr><td>Ukupno upisanih ECTS: </td>'
          f'<td>{ukupno_ects}</td><td></tr>')
    print('</table>')

    


# 1. Spremi u kolačiće (Set-Cookie header mora biti PRVI)
if method == 'POST':
    spremi_u_cookies()

# 2. Content-type header
print('Content-type: text/html\n')

# 3. Koji view prikazati
next_view = params.getvalue('next_view', '1')

# 4. HTML
print('''<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Odabir predmeta</title>
</head>
<body>
<h1>Odabir predmeta</h1>
<form method="post" action="vjezba3.py">''')

# 5. Navigacija (submit button za post metodu)
print('<nav>')
for year_id, year_name in subjects.year_names.items():
    print(f'<button type="submit" name="next_view" value="{year_id}">{year_name}</button>')
print('<button type="submit" name="next_view" value="upisni">Upisni list</button>')
print('</nav><hr>')


# 6. Sadržaj
if next_view == 'upisni':
    ispis_upisnog_lista()
else:
    try:
        year = int(next_view)
        ispis_predmeta_godine(year if year in subjects.year_names else 1)
    except ValueError:
        ispis_predmeta_godine(1)

print('</form>')
print('</body></html>')