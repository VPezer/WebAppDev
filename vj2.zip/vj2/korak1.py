#!C:\ProgramData\Anaconda3\python.exe
import cgi
import cgitb
cgitb.enable()



print("""
<!DOCTYPE html>
<html lang="hr">
<head>
    <meta charset="UTF-8"> 
    <title>Registracija</title>
</head>
<body>
    <h2>Registracija korisnika</h2>
    <p>Korak 1 od 3 - Unos podataka</p>
    <form action="korak2.py" method="post">
        <label for="ime">Ime:</label>
        <input type="text" id="ime" name="ime" required><br><br>
      
        <label for="lozinka">Lozinka:</label>
        <input type="password" name="lozinka" required><br><br>
      
        <label for="lozinka">Lozinka ponovno:</label>
        <input type="password" name="lozinka2" required><br><br>  

        

        <input type="submit" value="Dalje">
    </form>
    
      
</body>
</html>""")
