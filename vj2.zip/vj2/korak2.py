#!C:\ProgramData\Anaconda3\python.exe
import cgi
import cgitb
cgitb.enable()

print("Content-type: text/html; charset=utf-8\r\n\r\n")

form = cgi.FieldStorage()
ime      = form.getvalue("ime", "")
lozinka  = form.getvalue("lozinka", "")
lozinka2 = form.getvalue("lozinka2", "")

if lozinka != lozinka2:
    print("""
<!DOCTYPE html>
<html lang="hr">
<head>
    <meta charset="UTF-8">
    <title>Greska!</title>
</head>
<body>
    <p>Lozinke se ne podudaraju!</p>
    <a href="korak1.py?greska=1">Na pocetak</a>
</body>
</html>
""")
else:
    print(f"""<!DOCTYPE html>
<html lang="hr">
<head>
    <meta charset="UTF-8">
    <title>Registracija - Korak 2</title>
</head>
<body>
    <h2>Registracija korisnika</h2>
    <p>Korak 2 od 3 - Kontakt podaci</p>
    <form action="korak3.py" method="post">
        <input type="hidden" name="ime"     value="{ime}">
        <input type="hidden" name="lozinka" value="{lozinka}">

        <label for="email">Enter your email:</label>
        <input type="email" id="email" name="email"><br>

        <label for="smjer">Smjer:</label>
        <select id="smjer" name="smjer" required>
            <option value="">-- Odaberi smjer --</option>
            <option value="Informatika">Informatika</option>
            <option value="Racunarstvo">Racunarstvo</option>
            <option value="Informacijska tehnologija">Informacijska tehnologija</option>
            <option value="Elektrotehnika">Elektrotehnika</option>
        </select>
        <br>

        <label>Status:</label>
        <div class="radio-group">
            <label><input type="radio" name="status" value="Redovni" required> Redovni</label>
            <label><input type="radio" name="status" value="Izvanredni"> Izvanredni</label>
        </div>

        <label>
            <input type="checkbox" name="zavrsni" value="Da">
            Zavrsni rad
        </label>
        <br>

        <input type="submit" value="Dalje">
    </form>
</body>
</html>""")
