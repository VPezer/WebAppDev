#!C:\ProgramData\Anaconda3\python.exe

import cgi

params = cgi.FieldStorage()

ime      = params.getvalue("ime") or "-"
email    = params.getvalue("email") or "-"
status   = params.getvalue("status") or "-"
smjer    = params.getvalue("smjer") or "-"
zavrsni  = params.getvalue("zavrsni") or "Ne"
napomene = params.getvalue("napomene") or "Nema napomena"

print(f"""
<!DOCTYPE html>
<html>
<body>
<h2>Uneseni podaci</h2>
<table border="1" cellpadding="5">
  <tr><td><b>Ime:</b></td><td>{ime}</td></tr>
  <tr><td><b>E-mail:</b></td><td>{email}</td></tr>
  <tr><td><b>Status:</b></td><td>{status}</td></tr>
  <tr><td><b>Smjer:</b></td><td>{smjer}</td></tr>
  <tr><td><b>Završni rad:</b></td><td>{zavrsni}</td></tr>
  <tr><td><b>Napomene:</b></td><td>{napomene}</td></tr>
</table>
<br>
<a href="/cgi-bin/vj2/korak1.py">Na pocetak</a>
</body>
</html>
""")
