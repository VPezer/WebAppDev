#!C:\ProgramData\Anaconda3\python.exe
import cgi
import cgitb
cgitb.enable()

print("Content-type: text/html; charset=utf-8\r\n\r\n")

form    = cgi.FieldStorage()
ime     = form.getvalue("ime", "")
lozinka = form.getvalue("lozinka", "")
email   = form.getvalue("email", "")
smjer   = form.getvalue("smjer", "")
status  = form.getvalue("status", "")
zavrsni = form.getvalue("zavrsni", "")

print(f"""<!DOCTYPE html>
<html lang="hr">
<head>
    <meta charset="UTF-8">
    <title>Registracija - Korak 3</title>
</head>
<body>
    <h2>Registracija korisnika</h2>
    <p>Korak 3 od 3 - Napomena</p>
    <form action="rezultat.py" method="post">
        <input type="hidden" name="ime"     value="{ime}">
        <input type="hidden" name="lozinka" value="{lozinka}">
        <input type="hidden" name="email"   value="{email}">
        <input type="hidden" name="smjer"   value="{smjer}">
        <input type="hidden" name="status"  value="{status}">
        <input type="hidden" name="zavrsni" value="{zavrsni}">

        <label for="napomene">Napomene:</label>
        <textarea id="napomene" name="napomene" rows="4"
                  placeholder="Upisi napomenu"></textarea>
        <br>
        <input type="submit" value="Zavrsi registraciju">
    </form>
</body>
</html>""")
