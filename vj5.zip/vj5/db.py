#!c:/msys64/mingw64/bin/python.exe
import mysql.connector
import json

db_conf = {
    "host":    "localhost",
    "db_name": "iwa_vjezba5",
    "user":    "root",
    "passwd":  ""
}

def get_DB_connection():
    return mysql.connector.connect(
        host=db_conf["host"], user=db_conf["user"],
        password=db_conf["passwd"], database=db_conf["db_name"]
    )

# --- SESSIONS ---
def create_session():
    mydb = get_DB_connection()
    cursor = mydb.cursor()
    cursor.execute("INSERT INTO sessions (data) VALUES (%s)", (json.dumps({}),))
    mydb.commit()
    return cursor.lastrowid

def get_session(session_id):
    mydb = get_DB_connection()
    cursor = mydb.cursor()
    cursor.execute("SELECT * FROM sessions WHERE session_id=" + str(session_id))
    row = cursor.fetchone()
    return row[0], json.loads(row[1])

def replace_session(session_id, data):
    mydb = get_DB_connection()
    cursor = mydb.cursor()
    cursor.execute("REPLACE INTO sessions(session_id, data) VALUES (%s,%s)",
                   (session_id, json.dumps(data)))
    mydb.commit()

def destroy_session(session_id):
    mydb = get_DB_connection()
    cursor = mydb.cursor()
    cursor.execute("DELETE FROM sessions WHERE session_id=(%s)", (session_id,))
    mydb.commit()

# --- USERS ---
def create_user(ime, email, password_hash):
    mydb = get_DB_connection()
    cursor = mydb.cursor()
    cursor.execute(
        "INSERT INTO users (ime, email, password) VALUES (%s, %s, %s)",
        (ime, email, password_hash)
    )
    mydb.commit()
    return cursor.lastrowid

def get_user(email):                          # dohvati korisnika po emailu
    mydb = get_DB_connection()
    cursor = mydb.cursor()
    cursor.execute("SELECT * FROM users WHERE email=%s", (email,))
    return cursor.fetchone()                  # (id, ime, email, password_hash)

def get_user_by_id(user_id):
    mydb = get_DB_connection()
    cursor = mydb.cursor()
    cursor.execute("SELECT * FROM users WHERE id=%s", (user_id,))
    return cursor.fetchone()

def email_exists(email):
    return get_user(email) is not None

def ime_exists(ime):
    mydb = get_DB_connection()
    cursor = mydb.cursor()
    cursor.execute("SELECT * FROM users WHERE ime=%s", (ime,))
    return cursor.fetchone() is not None

def update_password(user_id, new_hash):
    mydb = get_DB_connection()
    cursor = mydb.cursor()
    cursor.execute("UPDATE users SET password=%s WHERE id=%s", (new_hash, user_id))
    mydb.commit()

# --- SUBJECTS ---
def get_subjects():
    mydb = get_DB_connection()
    cursor = mydb.cursor()
    cursor.execute("SELECT * FROM subjects")
    return cursor.fetchall()                  # [(id, kod, ime, bodovi, godina), ...]