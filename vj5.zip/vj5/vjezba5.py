#!c:/msys64/mingw64/bin/python.exe
import cgi
import os
import db
import session
import password_utils

params = cgi.FieldStorage()
method = os.environ.get('REQUEST_METHOD', 'GET').upper()

# 1. PROVJERA PRIJAVE (mora biti PRIJE svih headera)
user_id = session.get_logged_in_user_id()
if user_id is None:
    session.redirect('login.py')             # nije prijavljen → login

# 2. SPREMI ODABIR U SESIJU (mora biti PRIJE Content-type) - jer se koristi funkcija koja dohvaća session_id i postavlja cookie ako ne postoji
if method == 'POST':
    session_data_temp = session.get_session_data()
    for subject_kod in params.keys():
        if subject_kod != 'next_view':
            session_data_temp[subject_kod] = params.getvalue(subject_kod)
    db.replace_session(session.get_or_create_session_id(), session_data_temp)

# === 3. Content-type ===
print('Content-type: text/html\n')

# 4. Dohvati podatke o sesiji, korisniku i predmetima
session_data = session.get_session_data()
user         = db.get_user_by_id(user_id)
subjects     = db.get_subjects()             # [(id, kod, ime, bodovi, godina)]
next_view    = params.getvalue('next_view', '1')

year_names   = {1: '1st Year', 2: '2nd Year', 3: '3rd Year'}
status_names = {'not': 'Not selected', 'enr': 'Enrolled', 'pass': 'Passed'}

# -------------------------------------------------------
def dohvati_status(subject_kod):
    return session_data.get(subject_kod, 'not')

def ispis_predmeta(subject):
    _, kod, ime, bodovi, godina = subject
    status = dohvati_status(kod)
    print(f'<tr><td>{ime}</td><td>{bodovi}</td>')
    for status_id, status_name in status_names.items():
        checked = 'checked' if status == status_id else ''
        print(f'<td><input type="radio" name="{kod}" value="{status_id}" {checked}> {status_name}</td>')
    print('</tr>')

def ispis_predmeta_godine(year):
    print(f'<h2>{year_names[year]}</h2>')
    print('<table border="1"><tr><th>Predmet</th><th>ECTS</th>')
    for sn in status_names.values():
        print(f'<th>{sn}</th>')
    print('</tr>')
    for s in subjects:
        if s[4] == year:                     # s[4] = godina
            ispis_predmeta(s)
    print('</table>')

def ispis_upisnog_lista():
    print('<h2>Upisni list</h2>')
    print('<table border="1"><tr><th>Godina</th><th>Predmet</th><th>ECTS</th><th>Status</th></tr>')
    ukupno = 0
    for s in subjects:
        _, kod, ime, bodovi, godina = s
        status = dohvati_status(kod)
        yn = year_names.get(godina, str(godina))
        if status == 'not':
            sn = 'Not enrolled or passed!'
        else:
            sn = status_names[status]
            if status == 'enr':
                ukupno += bodovi
        print(f'<tr><td>{yn}</td><td>{ime}</td><td>{bodovi}</td><td>{sn}</td></tr>')
    print(f'<tr><td colspan="2"><strong>Ukupno ECTS (Enrolled)</strong></td>'
          f'<td><strong>{ukupno}</strong></td><td></td></tr>')
    print('</table>')

# -------------------------------------------------------
print(f'''<!DOCTYPE html><html><head><meta charset="UTF-8">
<title>Odabir predmeta</title></head><body>
<p>Hej <strong>{user[1]}</strong>!
   <a href="change_password.py">Promijeni lozinku</a> |
   <a href="logout.py">Odjava</a></p>
<h1>Odabir predmeta</h1>
<form method="post" action="vjezba5.py">''')

print('<nav>')
for year_id, year_name_str in year_names.items():
    print(f'<button type="submit" name="next_view" value="{year_id}">{year_name_str}</button>')
print('<button type="submit" name="next_view" value="upisni">Upisni list</button>')
print('</nav><hr>')

if next_view == 'upisni':
    ispis_upisnog_lista()
else:
    try:
        year = int(next_view)
        ispis_predmeta_godine(year if year in year_names else 1)
    except ValueError:
        ispis_predmeta_godine(1)

print('</form></body></html>')