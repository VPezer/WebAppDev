#!c:/msys64/mingw64/bin/python.exe
import cgi
import os
import db
import session
import password_utils

params = cgi.FieldStorage()
method = os.environ.get('REQUEST_METHOD', 'GET').upper()

def register():
    error = ''
    if method == 'POST':
        ime      = params.getvalue('ime', '')
        email    = params.getvalue('email', '')
        lozinka  = params.getvalue('lozinka', '')
        lozinka2 = params.getvalue('lozinka2', '')

        if db.ime_exists(ime):
            error = 'Korisnicko ime je zauzeto.'
        elif db.email_exists(email):
            error = 'Email je vec registriran.'
        elif lozinka != lozinka2:
            error = 'Lozinke se ne podudaraju.'
        elif len(lozinka) < 4:
            error = 'Lozinka mora imati najmanje 4 znaka.'
        else:
            hash = password_utils.hash_password(lozinka)
            db.create_user(ime, email, hash)
            session.redirect('login.py')

    print('Content-type: text/html\n')
    print(f'''<!DOCTYPE html><html><head><meta charset="UTF-8">
    <title>Registracija</title></head><body>
    <h2>Registracija</h2>''')
    if error:
        print(f'<p style="color:red">{error}</p>')
    print(f'''
    <form method="post" action="register.py">
        Ime:     <input type="text"     name="ime"      required><br><br>
        Email:   <input type="email"    name="email"    required><br><br>
        Lozinka: <input type="password" name="lozinka"  required><br><br>
        Ponovi:  <input type="password" name="lozinka2" required><br><br>
        <input type="submit" value="Registriraj se">
    </form>
    <a href="login.py">Vec imas racun? Prijavi se</a>
    </body></html>''')

register()