#!c:/msys64/mingw64/bin/python.exe
import cgi
import os
import db
import session
import password_utils

# MORA BITI PRVO
user_id = session.get_logged_in_user_id()
if user_id is None:
    session.redirect('login.py')
params = cgi.FieldStorage()
method = os.environ.get('REQUEST_METHOD', 'GET').upper()

print('Content-type: text/html')
print()

user = db.get_user_by_id(user_id)
error = ''
uspjeh = False

if method == 'POST':
    stara = params.getvalue('stara', '')
    nova = params.getvalue('nova', '')
    nova2 = params.getvalue('nova2', '')

    if not stara or not nova or not nova2:
        error = 'Sva polja su obavezna.'
    elif not password_utils.verify_password(stara, bytes(user[3])):
        error = 'Stara lozinka nije točna.'
    elif nova != nova2:
        error = 'Nove lozinke se ne podudaraju.'
    else:
        db.update_password(user_id, password_utils.hash_password(nova))
        uspjeh = True

print(f"<h2>Promjena lozinke za {user[1]}</h2>")

if error:
    print(f"<p style='color:red'>{error}</p>")
if uspjeh:
    print("<p style='color:green'>Lozinka promijenjena.</p>")

print('''
<form method="post" action="change_password.py">
    <label>Stara lozinka:</label>
    <input type="password" name="stara" required><br><br>

    <label>Nova lozinka:</label>
    <input type="password" name="nova" required><br><br>

    <label>Ponovi novu lozinku:</label>
    <input type="password" name="nova2" required><br><br>

    <input type="submit" value="Promijeni lozinku">
</form>
''')