#!c:/msys64/mingw64/bin/python.exe
import session

#Briše sesiju iz baze i kolačić iz preglednika
session.logout()

#Preusmjeri na login
session.redirect('login.py')