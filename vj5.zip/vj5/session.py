#!c:/msys64/mingw64/bin/python.exe
import db
import os
import sys
from http import cookies

_session_id = None

def get_or_create_session_id():
    global _session_id
    if _session_id is not None:
        return _session_id
    http_cookies_str = os.environ.get('HTTP_COOKIE', '')
    all_cookies = cookies.SimpleCookie(http_cookies_str)
    session_id = all_cookies.get("session_id").value if all_cookies.get("session_id") else None
    if session_id is None:
        session_id = db.create_session()
        c = cookies.SimpleCookie()
        c["session_id"] = session_id
        print(c.output())
    _session_id = int(session_id)
    return _session_id

def add_to_session(key, value):
    session_id = get_or_create_session_id()
    _, data = db.get_session(session_id)
    data[key] = value
    db.replace_session(session_id, data)

def get_session_data():
    session_id = get_or_create_session_id()
    _, data = db.get_session(session_id)
    return data

def get_logged_in_user_id():
    data = get_session_data()
    return data.get('user_id', None)          # None = nije prijavljen

def logout():
    session_id = get_or_create_session_id()
    db.destroy_session(session_id)            # briše iz baze
    c = cookies.SimpleCookie()
    c["session_id"] = ""
    c["session_id"]["expires"] = "Thu, 01 Jan 1970 00:00:00 GMT"  # briše kolačić
    print(c.output())

def redirect(url):
    print(f"Location: {url}")
    print()
    sys.exit()