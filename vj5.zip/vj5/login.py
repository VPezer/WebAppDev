#!c:/msys64/mingw64/bin/python.exe
import cgi
import os
import db
import session
import password_utils

params = cgi.FieldStorage()
method = os.environ.get('REQUEST_METHOD', 'GET').upper()

def login():
    error = ''
    if method == 'POST':
        email   = params.getvalue('email', '')
        lozinka = params.getvalue('lozinka', '')
        user = db.get_user(email)             # (id, ime, email, password_hash)

        if user is None:
            error = 'Korisnik s tim emailom ne postoji.'
        elif not password_utils.verify_password(lozinka, bytes(user[3])):
            error = 'Pogresna lozinka!'
        else:
            # Uspjesna prijava -> spremi user_id u sesiju
            session.add_to_session('user_id', user[0])
            session.redirect('vjezba5.py')

    print('Content-type: text/html\n')
    print(f'''<!DOCTYPE html><html><head><meta charset="UTF-8">
    <title>Prijava</title></head><body>
    <h2>Prijava</h2>''')
    if error:
        print(f'<p style="color:red">{error}</p>')
    print(f'''
    <form method="post" action="login.py">
        Email:   <input type="email"    name="email"   required><br><br>
        Lozinka: <input type="password" name="lozinka" required><br><br>
        <input type="submit" value="Prijavi se">
    </form>
    <a href="register.py">Nemas racun? Registriraj se</a>
    </body></html>''')

login()