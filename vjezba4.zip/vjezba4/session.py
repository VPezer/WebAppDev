#!C:/ProgramData/Anaconda3/python.exe
import mysql.connector
import db
import os
from http import cookies

_session_id = None   # cache — sprječava kreiranje duplikata sesije

def get_or_create_session_id():
    global _session_id
    if _session_id is not None:     # već znamo id, vrati odmah, ne čita opet cookie
        return _session_id

    http_cookies_str = os.environ.get('HTTP_COOKIE', '')
    all_cookies = cookies.SimpleCookie(http_cookies_str)
    session_id = all_cookies.get("session_id").value if all_cookies.get("session_id") else None

    if session_id is None:          # prvi posjet → kreiraj novu sesiju
        session_id = db.create_session()
        cookie = cookies.SimpleCookie()
        cookie["session_id"] = session_id
        print(cookie.output())      # Set-Cookie: session_id=5 (mora biti PRVI!)

    _session_id = int(session_id)
    return _session_id

def add_to_session(params):
    session_id = get_or_create_session_id()
    _, data = db.get_session(session_id)     # dohvati postojeće podatke
    for subject_id in params.keys():
        if subject_id != 'next_view':        # preskoči navigacijski parametar
            data[subject_id] = params.getvalue(subject_id)
    db.replace_session(session_id, data)     # spremi sve natrag u bazu nije update

def get_session_data():
    session_id = get_or_create_session_id()
    _, data = db.get_session(session_id)
    return data