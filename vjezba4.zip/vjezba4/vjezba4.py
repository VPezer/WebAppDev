#!C:/ProgramData/Anaconda3/python.exe
import cgi
import os
import session
import predmeti   # predmeti.py

params = cgi.FieldStorage()
method = os.environ.get('REQUEST_METHOD', 'GET').upper()

# spremanje u sesiju prije 'content-type' headera → cookie se šalje odmah, 
# a ne nakon HTML-a
if method == 'POST':
    session.add_to_session(params)

# content type

#dohvati podatke iz sesije jednom i spremi u varijablu (cache) 
#izbjegava višestruke upite prema bazi
session_data = session.get_session_data()

print('Content-type: text/html\n\n')


#dohvati status predmeta iz sesije (ako nema, vrati 'not')
def dohvati_status(subject_id):
    return session_data.get(subject_id, 'not')

#ispis jednog predmeta (jedan red tablice) s radio botunima za odabir statusa
def ispis_predmeta(subject_id, subject_data):
    status = dohvati_status(subject_id)
    print(f'<tr><td>{subject_data["name"]}</td><td>{subject_data["ects"]}</td>')
    for status_id, status_name in predmeti.status_names.items():
        checked = 'checked' if status == status_id else ''
        print(f'<td><input type="radio" name="{subject_id}" '
              f'value="{status_id}" {checked}> {status_name}</td>')
    print('</tr>')

#ispis predmeta određene godine
def ispis_predmeta_godine(year):
    print(f'<h2>{predmeti.year_names[year]}</h2>')
    print('<table border="1"><tr><th>Predmet</th><th>ECTS</th>')
    for sn in predmeti.status_names.values():
        print(f'<th>{sn}</th>')
    print('</tr>')
    for subject_id, subject_data in predmeti.subjects.items():
        if subject_data['year'] == year:
            ispis_predmeta(subject_id, subject_data)
    print('</table>')

#ispis upisnog lista (sve predmete koji nisu 'not' i zbroj ECTS-a za 'enr')
def ispis_upisnog_lista():
    print('<h2>Upisni list</h2>')
    print('<table border="1">')
    print('<tr><th>Godina</th><th>Predmet</th><th>ECTS</th><th>Status</th></tr>')
    ukupno_ects = 0
    for subject_id, subject_data in predmeti.subjects.items():
        status = dohvati_status(subject_id)
        year_name = predmeti.year_names[subject_data['year']]
        ects = subject_data['ects']

        if status == 'not':
            status_prikaz = 'Nije upisan niti položen'   # ← NOVO
        else:
            status_prikaz = predmeti.status_names[status]
            if status == 'enr':
                ukupno_ects += ects

        print(f'<tr><td>{year_name}</td><td>{subject_data["name"]}</td>'
              f'<td>{ects}</td><td>{status_prikaz}</td></tr>')

    print(f'<tr><td colspan="2"><strong>Ukupno ECTS (Enrolled)</strong></td>'
          f'<td><strong>{ukupno_ects}</strong></td><td></td></tr>')
    print('</table>')
#glavni html ispis s navigacijom između godina i upisnog lista
next_view = params.getvalue('next_view', '1')

print('''<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Odabir predmeta</title>
</head>
<body>
<h1>Odabir predmeta</h1>
<form method="post" action="vjezba4.py">''')

print('<nav>')
for year_id, year_name_str in predmeti.year_names.items():
    print(f'<button type="submit" name="next_view" value="{year_id}">{year_name_str}</button>')
print('<button type="submit" name="next_view" value="upisni">Upisni list</button>')
print('</nav><hr>')

if next_view == 'upisni':
    ispis_upisnog_lista()
else:
    try:
        year = int(next_view)
        ispis_predmeta_godine(year if year in predmeti.year_names else 1)
    except ValueError:
        ispis_predmeta_godine(1)

print('</form>')
print('</body></html>')