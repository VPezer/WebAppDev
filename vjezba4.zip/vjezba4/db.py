#!C:/ProgramData/Anaconda3/python.exe
import mysql.connector
import json

db_conf = {
    "host": "localhost",
    "db_name": "iwa_vjezba4",
    "user": "root",
    "passwd": ""
}

def get_DB_connection():
    return mysql.connector.connect(
        host=db_conf["host"],
        user=db_conf["user"],
        password=db_conf["passwd"],
        database=db_conf["db_name"]
    )

def create_session():
    query = "INSERT INTO sessions (data) VALUES (%s)"
    values = (json.dumps({}),)          # prazna sesija → "{}"
    mydb = get_DB_connection()
    cursor = mydb.cursor()
    cursor.execute(query, values)
    mydb.commit()
    return cursor.lastrowid             # vraća novi session_id

def get_session(session_id):
    mydb = get_DB_connection()
    cursor = mydb.cursor()
    cursor.execute("SELECT * FROM sessions WHERE session_id=" + str(session_id))
    myresult = cursor.fetchone()
    return myresult[0], json.loads(myresult[1])  # (id, dict)

def replace_session(session_id, data):
    mydb = get_DB_connection()
    cursor = mydb.cursor()
    cursor.execute("""
        REPLACE INTO sessions(session_id, data)
        VALUES (%s, %s)""",
        (session_id, json.dumps(data))) # dict → JSON string
    mydb.commit()